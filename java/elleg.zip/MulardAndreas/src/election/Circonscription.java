package election;

public class Circonscription {
	public Circonscription(String departement, int circonscription, String nom, String prenom, String nuance, int vote,
			float pourcentage) {
		this.departement = departement;
		this.circonscription = circonscription;
		this.nom = nom;
		this.prenom = prenom;
		this.nuance = nuance;
		this.vote = vote;
		this.pourcentage = pourcentage;
	}
	public String departement;
	public int circonscription;
	public String nom;
	public String prenom;
	public String nuance;
	public int vote;
	public float pourcentage;
}
