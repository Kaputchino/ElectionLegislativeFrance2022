package election;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReaderElection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Circonscription> list=readCirc(new File("circsbnan.txt"));
		//for(int i=0;i<list.size();i++) {
			//System.out.println(list.get(i));
		//}
		addToDBCirconscription(list);
	}
	
	public static ArrayList read(File file) {
		BufferedReader br;
		ArrayList<Candidate> list=new ArrayList<Candidate>();
		
		String st;
		try {
			br = new BufferedReader(new FileReader(file));
			st=br.readLine();

			while((st=br.readLine())!= null) {
				String[] table=st.split(";");
				List<String> l1=(List<String>) Arrays.asList(table);
				ArrayList<String> la=new ArrayList<String>(l1);
				la.add(" ");

				for (int i=19;i<table.length;i=i+0) {
					Candidate can=new Candidate(Integer.parseInt(la.get(i)), la.get(i+1), la.get(i+2), la.get(i+3),
							la.get(i+4), Integer.parseInt(la.get(i+5)), Float.parseFloat(la.get(i+6).replace(',', '.')),
							 Float.parseFloat(la.get(i+7).replace(',', '.')), la.get(i+8),la.get(0),Integer.parseInt(la.get(2)));
					list.add(can);
					i=i+9;
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
		
	}
	public static ArrayList readCirc(File file) {
		BufferedReader br;
		ArrayList<Circonscription> list=new ArrayList<Circonscription>();
		
		String st;
		try {
			br = new BufferedReader(new FileReader(file));
			while((st=br.readLine())!= null) {
				String[] table=st.split(",");
				List<String> l1=(List<String>) Arrays.asList(table);
				ArrayList<String> la=new ArrayList<String>(l1);
				la.add(" ");
				String prenom="";
				String nom="";
				String nuance="";
				int nbVote=0;
				float pourcentage=0;
				System.out.println(la);
				System.out.println(la.get(1));
				if(Integer.parseInt(la.get(5))>Integer.parseInt(la.get(10))) {
					prenom=la.get(3);
					nom=la.get(2);
					nuance=la.get(4);
					nbVote=Integer.parseInt(la.get(5));
					pourcentage=Float.parseFloat(la.get(6));
				}
				else {
					prenom=la.get(8);
					nom=la.get(7);
					nuance=la.get(9);
					nbVote=Integer.parseInt(la.get(10));
					pourcentage=Float.parseFloat(la.get(11));
				}
				Circonscription cs=new Circonscription(la.get(0),Integer.parseInt(la.get(1)), nom, prenom, nuance, nbVote, pourcentage);
				list.add(cs);
				
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
		
	}	
	public static void addToDB(ArrayList<Candidate> list) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/election","root","");
			for (int i=0;i<list.size();i++) {
				System.out.println(i);
				Statement stmt=con.createStatement();  
				String sql ="INSERT INTO `gouv2` VALUES ("+list.get(i).nbPanneau+",'"+list.get(i).sexe+"','"+
						doubleGuillemet(list.get(i).nom)+"','"+doubleGuillemet(list.get(i).prenom)+"','"+list.get(i).nuance
						+"',"+list.get(i).voix+","+list.get(i).voixIns+","
						+list.get(i).voixExp+",'"+list.get(i).siege+"',"+i+",'"+list.get(i).departememntNb+"',"+list.get(i).circonscription+")";
				System.out.println(sql);
				stmt.execute(sql);
			}

			System.out.println("ajout");
			con.close();  
			}
		catch(Exception e){ 
			System.out.println(e);
			}  
	}
	public static String doubleGuillemet(String st) {
		ArrayList newStAL=new ArrayList<>();
		for (int i=0; i<st.length();i++) {
			if(st.charAt(i)=='\'') {
				newStAL.add('\'');
			}
			newStAL.add(st.charAt(i));
		}
		String newSt="";
		for (int i=0;i<newStAL.size();i++) {
			newSt+=newStAL.get(i);
		}
		return newSt;
	}
	public static void addToDBCirconscription(ArrayList<Circonscription> list) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/election","root","");
			for (int i=0;i<list.size();i++) {
				System.out.println(i);
				Statement stmt=con.createStatement();  
				String sql ="INSERT INTO `circonscription` VALUES ("
						+i+",'"
						+list.get(i).departement+"',"
						+list.get(i).circonscription+",'"
						+doubleGuillemet(list.get(i).nom)+"','"
						+doubleGuillemet(list.get(i).prenom)+"','"
						+list.get(i).nuance+"',"
						+list.get(i).vote+","
						+list.get(i).pourcentage
						+")";
				System.out.println(sql);
				stmt.execute(sql);
			}
			System.out.println("ajout");
			con.close();  
			}
		catch(Exception e){ 
			System.out.println(e);
			}  
	}
}
