package election;

public class Candidate {
	public Candidate(int nbPanneau, String sexe, String nom, String prenom, String nuance, int voix, float voixIns,
			float voixExp, String siege, String departememntNb, int circonscription) {
		this.nbPanneau = nbPanneau;
		this.sexe = sexe;
		this.nom = nom;
		this.prenom = prenom;
		this.nuance = nuance;
		this.voix = voix;
		this.voixIns = voixIns;
		this.voixExp = voixExp;
		this.siege = siege;
		this.circonscription=circonscription;
		this.departememntNb=departememntNb;
	}
	public int nbPanneau;
	public String sexe;
	public String nom;
	public String prenom;
	public String nuance;
	public int voix;
	public float voixIns;
	public float voixExp;
	public String siege;
	public String departememntNb;
	public int circonscription;

}
