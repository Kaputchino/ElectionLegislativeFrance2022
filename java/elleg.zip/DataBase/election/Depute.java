package election;

public class Depute {
	public int id;
	public String prenom;
	public String nom;
	public String region;
	public String departement;
	public int circonscription;
	public String profession;
	public String groupePolitiqueComplet;
	public String groupePolitiqueAbrege;
}
